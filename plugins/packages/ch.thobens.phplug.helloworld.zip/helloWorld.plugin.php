<?php
class HelloWorld implements IPhplugin {
	
	public function start() {
		echo "hello world!";	
	}
}
?>